package OOP.Abstraction.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}
