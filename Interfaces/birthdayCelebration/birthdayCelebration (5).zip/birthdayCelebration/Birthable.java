package birthdayCelebration;

public interface Birthable {
    String getBirthDate();
}
