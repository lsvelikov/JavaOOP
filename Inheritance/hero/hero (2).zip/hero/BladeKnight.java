package hero;

public class BladeKnight extends DarkKnight{

    public BladeKnight(String userName, int level) {
        super(userName, level);
    }
}
