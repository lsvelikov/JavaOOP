package hero;

public class Knight extends Hero{

    public Knight(String userName, int level) {
        super(userName, level);
    }
}
