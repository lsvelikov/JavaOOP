package hero;

public class MuseElf extends Elf{

    public MuseElf(String userName, int level) {
        super(userName, level);
    }
}
