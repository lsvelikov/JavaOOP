package speed;

public class Main {
}
